import { Reply, Edit, Trash2, Smile } from "lucide-react";
import { useStore } from "../store/useStore";

interface MessageToolbarProps {
  message: any;
  isOwnMessage: boolean;
  className?: string;
}

export function MessageToolbar({ message, isOwnMessage, className }: MessageToolbarProps) {
  const { deleteMessage, addReaction } = useStore();

  const handleReaction = (emoji: string) => {
    addReaction(message.channelId || "1", message.id, emoji, "1");
  };

  return (
    <div className={`flex items-center space-x-1 ${className}`}>
      <button
        className="p-1 rounded hover:bg-gray-600 text-gray-400 hover:text-white transition-colors"
        title="Reply"
      >
        <Reply size={16} />
      </button>
      
      {isOwnMessage && (
        <button
          className="p-1 rounded hover:bg-gray-600 text-gray-400 hover:text-white transition-colors"
          title="Edit"
        >
          <Edit size={16} />
        </button>
      )}
      
      {isOwnMessage && (
        <button
          className="p-1 rounded hover:bg-gray-600 text-gray-400 hover:text-white transition-colors"
          title="Delete"
          onClick={() => deleteMessage(message.channelId || "1", message.id)}
        >
          <Trash2 size={16} />
        </button>
      )}
      
      <div className="relative group">
        <button
          className="p-1 rounded hover:bg-gray-600 text-gray-400 hover:text-white transition-colors"
          title="Add Reaction"
        >
          <Smile size={16} />
        </button>
        
        {/* Quick reactions */}
        <div className="absolute bottom-full left-0 mb-2 bg-gray-800 rounded-lg shadow-lg p-2 flex space-x-1 opacity-0 group-hover:opacity-100 pointer-events-none group-hover:pointer-events-auto transition-opacity">
          {["👍", "❤️", "😂", "😮", "😢", "😡"].map((emoji) => (
            <button
              key={emoji}
              className="w-8 h-8 hover:bg-gray-700 rounded flex items-center justify-center text-lg"
              onClick={() => handleReaction(emoji)}
            >
              {emoji}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}