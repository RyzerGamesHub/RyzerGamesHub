import { useState } from "react";
import { MessageToolbar } from "./MessageToolbar";
import { formatTime } from "../utils/formatTime";
import { parseMarkdown } from "../utils/parseMarkdown";
import { useStore } from "../store/useStore";

interface MessageItemProps {
  message: any;
  showAvatar: boolean;
}

export function MessageItem({ message, showAvatar }: MessageItemProps) {
  const [showToolbar, setShowToolbar] = useState(false);
  const { user } = useStore();

  const isOwnMessage = user?.id === message.author.id;

  return (
    <div
      className={`group flex hover:bg-gray-750 px-4 py-2 -mx-4 rounded transition-colors ${
        showAvatar ? "mt-4" : ""
      }`}
      onMouseEnter={() => setShowToolbar(true)}
      onMouseLeave={() => setShowToolbar(false)}
    >
      {/* Avatar */}
      {showAvatar && (
        <div className="w-10 h-10 rounded-full bg-indigo-600 flex items-center justify-center text-white text-lg mr-3 flex-shrink-0">
          {message.author.avatar}
        </div>
      )}
      
      {/* Message content */}
      <div className="flex-1 min-w-0">
        {showAvatar && (
          <div className="flex items-baseline mb-1">
            <span className="font-medium text-white mr-2 hover:underline cursor-pointer">
              {message.author.username}
            </span>
            <span className="text-xs text-gray-400">
              {formatTime(message.timestamp)}
            </span>
            {message.edited && (
              <span className="text-xs text-gray-400 ml-1">(edited)</span>
            )}
          </div>
        )}
        
        {/* Message text */}
        <div className="text-gray-200 break-words">
          {parseMarkdown(message.content)}
        </div>
        
        {/* Reply indicator */}
        {message.replyTo && (
          <div className="mt-1 text-sm text-gray-400 italic">
            Replying to a message
          </div>
        )}
        
        {/* Reactions */}
        {message.reactions.length > 0 && (
          <div className="flex flex-wrap gap-1 mt-2">
            {message.reactions.map((reaction: any, index: number) => (
              <button
                key={index}
                className={`flex items-center px-2 py-1 rounded text-sm transition-colors ${
                  reaction.userIds.includes(user?.id || "")
                    ? "bg-indigo-600 text-white"
                    : "bg-gray-600 text-gray-200 hover:bg-gray-500"
                }`}
                onClick={() => {
                  // Handle reaction toggle
                }}
              >
                <span>{reaction.emoji}</span>
                <span className="ml-1">{reaction.count}</span>
              </button>
            ))}
          </div>
        )}
      </div>
      
      {/* Message toolbar */}
      {showToolbar && (
        <MessageToolbar
          message={message}
          isOwnMessage={isOwnMessage}
          className="opacity-0 group-hover:opacity-100 transition-opacity"
        />
      )}
    </div>
  );
}