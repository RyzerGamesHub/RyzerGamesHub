import { Hash, Volume2, Plus, Settings } from "lucide-react";
import { useStore } from "../store/useStore";

export function ChannelList() {
  const { currentServer, currentChannel, setCurrentChannel } = useStore();
  
  // Mock channels data
  const mockChannels = [
    { id: "1", name: "general", type: "text" as const, unread: 0 },
    { id: "2", name: "random", type: "text" as const, unread: 2 },
    { id: "3", name: "gaming", type: "text" as const, unread: 0 },
    { id: "4", name: "General Voice", type: "voice" as const, unread: 0 },
    { id: "5", name: "Gaming Voice", type: "voice" as const, unread: 0 },
  ];

  const textChannels = mockChannels.filter(c => c.type === "text");
  const voiceChannels = mockChannels.filter(c => c.type === "voice");

  if (!currentServer) {
    return (
      <div className="w-60 bg-gray-800 flex items-center justify-center">
        <div className="text-gray-500 text-center">
          <Users size={48} className="mx-auto mb-4 opacity-50" />
          <p>Select a server to view channels</p>
        </div>
      </div>
    );
  }

  return (
    <div className="w-60 bg-gray-800 flex flex-col">
      {/* Server header */}
      <div className="h-12 px-4 flex items-center shadow-md border-b border-gray-900">
        <h2 className="font-bold text-white">Mock Server</h2>
        <div className="ml-auto flex space-x-2">
          <button className="text-gray-400 hover:text-white">
            <Plus size={16} />
          </button>
          <button className="text-gray-400 hover:text-white">
            <Settings size={16} />
          </button>
        </div>
      </div>
      
      {/* Channel list */}
      <div className="flex-1 overflow-y-auto">
        {/* Text channels */}
        <div className="mb-4">
          <div className="px-2 py-2">
            <div className="flex items-center text-xs font-semibold text-gray-400 uppercase tracking-wider">
              <Hash size={12} className="mr-1" />
              Text Channels
            </div>
          </div>
          
          {textChannels.map((channel) => (
            <button
              key={channel.id}
              onClick={() => setCurrentChannel(channel.id)}
              className={`w-full px-2 py-1 flex items-center text-sm hover:bg-gray-700 group ${
                currentChannel === channel.id ? "bg-gray-700 text-white" : "text-gray-300"
              }`}
            >
              <Hash size={16} className="mr-1 text-gray-400" />
              <span className="flex-1 text-left">{channel.name}</span>
              {channel.unread > 0 && (
                <div className="w-5 h-5 bg-red-500 text-white text-xs rounded-full flex items-center justify-center">
                  {channel.unread}
                </div>
              )}
            </button>
          ))}
        </div>
        
        {/* Voice channels */}
        <div>
          <div className="px-2 py-2">
            <div className="flex items-center text-xs font-semibold text-gray-400 uppercase tracking-wider">
              <Volume2 size={12} className="mr-1" />
              Voice Channels
            </div>
          </div>
          
          {voiceChannels.map((channel) => (
            <button
              key={channel.id}
              className="w-full px-2 py-1 flex items-center text-sm hover:bg-gray-700 group text-gray-300"
            >
              <Volume2 size={16} className="mr-1 text-gray-400" />
              <span className="flex-1 text-left">{channel.name}</span>
            </button>
          ))}
        </div>
      </div>
      
      {/* User info */}
      <div className="h-14 px-2 bg-gray-850 border-t border-gray-900 flex items-center">
        <div className="w-8 h-8 bg-indigo-600 rounded-full flex items-center justify-center text-white text-sm">
          U
        </div>
        <div className="ml-2 flex-1">
          <div className="text-sm text-white font-medium">TestUser</div>
          <div className="text-xs text-gray-400">#0001</div>
        </div>
        <button className="text-gray-400 hover:text-white">
          <Settings size={16} />
        </button>
      </div>
    </div>
  );
}