import { useEffect, useRef, useState } from "react";
import { MessageItem } from "./MessageItem";
import { useStore } from "../store/useStore";

export function MessageFeed() {
  const { currentChannel, messages, typing } = useStore();
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  const mockMessages = [
    {
      id: "1",
      author: {
        id: "2",
        username: "Alice",
        avatar: "👩",
        email: "alice@example.com",
        roleId: "role-1"
      },
      content: "Welcome to the server! Feel free to introduce yourself.",
      timestamp: new Date(Date.now() - 3600000),
      edited: null,
      reactions: [
        { emoji: "👋", count: 3, userIds: ["1", "3", "4"] }
      ],
      replyTo: null,
      threadId: null,
      attachments: []
    },
    {
      id: "2",
      author: {
        id: "3",
        username: "Bob",
        avatar: "👨",
        email: "bob@example.com",
        roleId: "role-2"
      },
      content: "Hey everyone! I'm Bob, nice to meet you all!",
      timestamp: new Date(Date.now() - 3000000),
      edited: null,
      reactions: [],
      replyTo: "1",
      threadId: null,
      attachments: []
    },
    {
      id: "3",
      author: {
        id: "4",
        username: "Charlie",
        avatar: "🧑",
        email: "charlie@example.com",
        roleId: "role-1"
      },
      content: "Hi Bob! I'm Charlie, excited to be here!",
      timestamp: new Date(Date.now() - 2400000),
      edited: null,
      reactions: [
        { emoji: "😊", count: 1, userIds: ["3"] }
      ],
      replyTo: null,
      threadId: null,
      attachments: []
    }
  ];

  const channelMessages = currentChannel ? mockMessages : [];

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [channelMessages.length]);

  const handleScroll = () => {
    if (!containerRef.current || isLoading) return;
    
    const { scrollTop } = containerRef.current;
    if (scrollTop === 0) {
      setIsLoading(true);
      setTimeout(() => {
        setIsLoading(false);
      }, 1000);
    }
  };

  if (!currentChannel) {
    return (
      <div className="flex-1 flex items-center justify-center bg-gray-700">
        <div className="text-center">
          <HashIcon size={48} className="mx-auto mb-4 text-gray-500" />
          <h3 className="text-xl font-semibold text-gray-300 mb-2">
            Welcome to Slate!
          </h3>
          <p className="text-gray-400">
            Select a channel to start messaging
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="flex-1 flex flex-col bg-gray-700">
      <div className="h-12 px-4 flex items-center shadow-md border-b border-gray-600 bg-gray-750">
        <HashIcon size={20} className="text-gray-400 mr-2" />
        <span className="font-semibold text-white">general</span>
        <div className="ml-auto text-xs text-gray-400">
          {channelMessages.length} messages
        </div>
      </div>
      
      <div
        ref={containerRef}
        onScroll={handleScroll}
        className="flex-1 overflow-y-auto px-4 py-4 space-y-4"
      >
        {isLoading && (
          <div className="text-center text-gray-400 py-2">
            Loading older messages...
          </div>
        )}
        
        {channelMessages.map((message, index) => (
          <MessageItem
            key={message.id}
            message={message}
            showAvatar={index === 0 || channelMessages[index - 1].author.id !== message.author.id}
          />
        ))}
        
        {typing.get(currentChannel)?.size > 0 && (
          <div className="flex items-center text-gray-400 text-sm">
            <div className="flex space-x-1">
              <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" />
              <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: "0.1s" }} />
              <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: "0.2s" }} />
            </div>
            <span className="ml-2">
              {Array.from(typing.get(currentChannel) || []).join(", ")} is typing...
            </span>
          </div>
        )}
        
        <div ref={messagesEndRef} />
      </div>
    </div>
  );
}

function HashIcon({ size, className }: { size: number; className?: string }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      className={className}
    >
      <line x1="4" y1="9" x2="20" y2="9"></line>
      <line x1="4" y1="15" x2="20" y2="15"></line>
      <line x1="10" y1="3" x2="8" y2="21"></line>
      <line x1="16" y1="3" x2="14" y2="21"></line>
    </svg>
  );
}