import { useState, useRef, useEffect } from "react";
import { Textarea } from "../components/ui/textarea";
import { Button } from "../components/ui/button";
import { Paperclip, Smile, Send } from "lucide-react";
import { useStore } from "../store/useStore";
import { useWebSocket } from "../hooks/useWebSocket";

export function Composer() {
  const [content, setContent] = useState("");
  const [isTyping, setIsTyping] = useState(false);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const typingTimeoutRef = useRef<NodeJS.Timeout>();
  
  const { currentChannel, user, setTyping } = useStore();
  const { sendMessage } = useWebSocket();

  useEffect(() => {
    // Auto-resize textarea
    if (textareaRef.current) {
      textareaRef.current.style.height = "auto";
      textareaRef.current.style.height = `${textareaRef.current.scrollHeight}px`;
    }
  }, [content]);

  const handleInputChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setContent(e.target.value);
    
    // Handle typing indicator
    if (!isTyping && currentChannel && user) {
      setIsTyping(true);
      setTyping(currentChannel, user.id, true);
    }
    
    // Clear existing timeout
    if (typingTimeoutRef.current) {
      clearTimeout(typingTimeoutRef.current);
    }
    
    // Set new timeout to stop typing indicator
    typingTimeoutRef.current = setTimeout(() => {
      if (currentChannel && user) {
        setIsTyping(false);
        setTyping(currentChannel, user.id, false);
      }
    }, 1000);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!content.trim() || !currentChannel) return;
    
    sendMessage(currentChannel, content.trim());
    setContent("");
    
    // Stop typing indicator
    if (isTyping && currentChannel && user) {
      setIsTyping(false);
      setTyping(currentChannel, user.id, false);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSubmit(e);
    }
  };

  return (
    <div className="px-4 pb-4 bg-gray-700">
      <form onSubmit={handleSubmit} className="bg-gray-600 rounded-lg">
        <div className="flex items-end p-3">
          <button
            type="button"
            className="p-2 text-gray-400 hover:text-white transition-colors"
            title="Upload File"
          >
            <Paperclip size={20} />
          </button>
          
          <Textarea
            ref={textareaRef}
            value={content}
            onChange={handleInputChange}
            onKeyDown={handleKeyDown}
            placeholder={`Message #${currentChannel || "channel"}`}
            className="flex-1 bg-transparent border-none resize-none text-white placeholder-gray-400 focus:outline-none min-h-[20px] max-h-32"
            rows={1}
          />
          
          <button
            type="button"
            className="p-2 text-gray-400 hover:text-white transition-colors"
            title="Add Emoji"
          >
            <Smile size={20} />
          </button>
          
          <Button
            type="submit"
            className="ml-2 bg-indigo-600 hover:bg-indigo-700 text-white p-2"
            disabled={!content.trim()}
          >
            <Send size={20} />
          </Button>
        </div>
      </form>
    </div>
  );
}