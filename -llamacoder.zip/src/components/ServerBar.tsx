import { Home, Users, Plus } from "lucide-react";
import { useStore } from "../store/useStore";

export function ServerBar() {
  const { servers, currentServer, setCurrentServer, unread } = useStore();
  
  // Mock servers data
  const mockServers = [
    { id: "1", name: "General", icon: "🏠", unread: 0 },
    { id: "2", name: "Gaming", icon: "🎮", unread: 3 },
    { id: "3", name: "Tech", icon: "💻", unread: 1 },
  ];

  return (
    <div className="w-20 bg-gray-950 flex flex-col items-center py-3 space-y-2">
      {/* Home button */}
      <button
        onClick={() => setCurrentServer(null)}
        className={`w-12 h-12 rounded-2xl flex items-center justify-center transition-all ${
          !currentServer
            ? "bg-indigo-600 text-white rounded-2xl"
            : "bg-gray-700 text-gray-300 hover:bg-gray-600 hover:rounded-2xl"
        }`}
      >
        <Home size={24} />
      </button>
      
      <div className="w-12 h-px bg-gray-700" />
      
      {/* Server list */}
      {mockServers.map((server) => (
        <button
          key={server.id}
          onClick={() => setCurrentServer(server.id)}
          className={`relative group transition-all ${
            currentServer === server.id
              ? "bg-indigo-600 text-white rounded-2xl"
              : "bg-gray-700 text-gray-300 hover:bg-gray-600 hover:rounded-2xl"
          }`}
        >
          <div className="w-12 h-12 flex items-center justify-center">
            <span className="text-2xl">{server.icon}</span>
          </div>
          
          {/* Unread indicator */}
          {server.unread > 0 && (
            <div className="absolute -top-1 -right-1 w-3 h-3 bg-red-500 rounded-full" />
          )}
          
          {/* Tooltip */}
          <div className="absolute left-full ml-2 px-2 py-1 bg-gray-800 text-white text-sm rounded opacity-0 group-hover:opacity-100 pointer-events-none whitespace-nowrap z-50">
            {server.name}
          </div>
        </button>
      ))}
      
      {/* Add server button */}
      <button className="w-12 h-12 rounded-2xl bg-gray-700 text-gray-300 hover:bg-green-600 hover:text-white hover:rounded-2xl transition-all flex items-center justify-center group">
        <Plus size={24} />
        <div className="absolute left-full ml-2 px-2 py-1 bg-gray-800 text-white text-sm rounded opacity-0 group-hover:opacity-100 pointer-events-none whitespace-nowrap z-50">
          Add Server
        </div>
      </button>
    </div>
  );
}