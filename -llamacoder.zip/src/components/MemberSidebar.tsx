import { Users, Crown, Shield, Star } from "lucide-react";
import { useStore } from "../store/useStore";

export function MemberSidebar() {
  const { currentServer } = useStore();
  
  // Mock members data
  const mockMembers = [
    { id: "1", username: "Alice", avatar: "👩", status: "online", role: "Admin", roleColor: "text-red-400" },
    { id: "2", username: "Bob", avatar: "👨", status: "online", role: "Moderator", roleColor: "text-blue-400" },
    { id: "3", username: "Charlie", avatar: "🧑", status: "idle", role: "Member", roleColor: "text-gray-400" },
    { id: "4", username: "Diana", avatar: "👩‍💼", status: "dnd", role: "Member", roleColor: "text-gray-400" },
    { id: "5", username: "Eve", avatar: "👱‍♀️", status: "offline", role: "Member", roleColor: "text-gray-400" },
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case "online": return "bg-green-500";
      case "idle": return "bg-yellow-500";
      case "dnd": return "bg-red-500";
      case "offline": return "bg-gray-500";
      default: return "bg-gray-500";
    }
  };

  const getRoleIcon = (role: string) => {
    switch (role) {
      case "Admin": return <Crown size={12} />;
      case "Moderator": return <Shield size={12} />;
      case "VIP": return <Star size={12} />;
      default: return null;
    }
  };

  if (!currentServer) {
    return null;
  }

  return (
    <div className="w-60 bg-gray-800 flex flex-col">
      {/* Header */}
      <div className="h-12 px-4 flex items-center shadow-md border-b border-gray-900">
        <Users size={20} className="text-gray-400 mr-2" />
        <span className="font-semibold text-white">Members</span>
        <span className="ml-auto text-xs text-gray-400">{mockMembers.length}</span>
      </div>
      
      {/* Members list */}
      <div className="flex-1 overflow-y-auto">
        {/* Online section */}
        <div className="mb-4">
          <div className="px-3 py-2">
            <div className="text-xs font-semibold text-gray-400 uppercase tracking-wider">
              Online — {mockMembers.filter(m => m.status !== "offline").length}
            </div>
          </div>
          
          {mockMembers
            .filter(m => m.status !== "offline")
            .map((member) => (
              <div
                key={member.id}
                className="flex items-center px-3 py-2 hover:bg-gray-700 cursor-pointer group"
              >
                <div className="relative">
                  <div className="w-8 h-8 rounded-full bg-indigo-600 flex items-center justify-center text-white text-sm">
                    {member.avatar}
                  </div>
                  <div className={`absolute bottom-0 right-0 w-3 h-3 ${getStatusColor(member.status)} rounded-full border-2 border-gray-800`} />
                </div>
                
                <div className="ml-3 flex-1 min-w-0">
                  <div className="flex items-center">
                    <span className="text-sm text-white font-medium truncate">
                      {member.username}
                    </span>
                    {getRoleIcon(member.role) && (
                      <span className={`ml-1 ${member.roleColor}`}>
                        {getRoleIcon(member.role)}
                      </span>
                    )}
                  </div>
                </div>
              </div>
            ))}
        </div>
        
        {/* Offline section */}
        <div>
          <div className="px-3 py-2">
            <div className="text-xs font-semibold text-gray-400 uppercase tracking-wider">
              Offline — {mockMembers.filter(m => m.status === "offline").length}
            </div>
          </div>
          
          {mockMembers
            .filter(m => m.status === "offline")
            .map((member) => (
              <div
                key={member.id}
                className="flex items-center px-3 py-2 hover:bg-gray-700 cursor-pointer group opacity-50"
              >
                <div className="relative">
                  <div className="w-8 h-8 rounded-full bg-gray-600 flex items-center justify-center text-white text-sm">
                    {member.avatar}
                  </div>
                  <div className={`absolute bottom-0 right-0 w-3 h-3 ${getStatusColor(member.status)} rounded-full border-2 border-gray-800`} />
                </div>
                
                <div className="ml-3 flex-1 min-w-0">
                  <div className="flex items-center">
                    <span className="text-sm text-gray-400 font-medium truncate">
                      {member.username}
                    </span>
                  </div>
                </div>
              </div>
            ))}
        </div>
      </div>
    </div>
  );
}