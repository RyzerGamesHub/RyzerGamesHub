import { useEffect, useState } from "react";
import { useStore } from "./store/useStore";
import { AuthForm } from "./components/AuthForm";
import { ServerBar } from "./components/ServerBar";
import { ChannelList } from "./components/ChannelList";
import { MessageFeed } from "./components/MessageFeed";
import { MemberSidebar } from "./components/MemberSidebar";
import { Composer } from "./components/Composer";
import { useWebSocket } from "./hooks/useWebSocket";
import { useAuth } from "./hooks/useAuth";

export default function App() {
  const { user, token, currentServer, currentChannel } = useStore();
  const { initializeAuth } = useAuth();
  const [isInitialized, setIsInitialized] = useState(false);

  useEffect(() => {
    initializeAuth().then(() => setIsInitialized(true));
  }, [initializeAuth]);

  useWebSocket();

  if (!isInitialized) {
    return (
      <div className="flex items-center justify-center h-screen bg-gray-900">
        <div className="text-white">Loading...</div>
      </div>
    );
  }

  if (!user || !token) {
    return (
      <div className="flex items-center justify-center h-screen bg-gray-900">
        <AuthForm />
      </div>
    );
  }

  return (
    <div className="flex h-screen bg-gray-900 text-gray-100 overflow-hidden">
      {/* Server Bar - Fixed, Non-Scrolling */}
      <ServerBar />
      
      {/* Channel List - Scrollable */}
      <ChannelList />
      
      {/* Main Content Area */}
      <div className="flex-1 flex flex-col">
        {/* Message Feed */}
        <MessageFeed />
        
        {/* Message Composer */}
        {currentChannel && <Composer />}
      </div>
      
      {/* Members Sidebar - Collapsible */}
      {currentServer && <MemberSidebar />}
    </div>
  );
}