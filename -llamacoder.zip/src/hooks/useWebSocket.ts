import { useEffect, useRef } from "react";
import { useStore } from "../store/useStore";

export function useWebSocket() {
  const { token, currentChannel, addMessage, updateMessage, deleteMessage, setTyping, updatePresence } = useStore();
  const wsRef = useRef<WebSocket | null>(null);
  const reconnectTimeoutRef = useRef<NodeJS.Timeout>();

  useEffect(() => {
    if (!token) return;

    const connect = () => {
      // Simulate WebSocket connection
      // In a real app, this would connect to an actual WebSocket server
      console.log("Connecting WebSocket...");
      
      // Simulate receiving messages
      const simulateIncomingMessage = () => {
        if (currentChannel && Math.random() > 0.7) {
          const mockMessage = {
            id: Date.now().toString(),
            author: {
              id: "2",
              username: "BotUser",
              avatar: "🤖",
              email: "bot@example.com",
              roleId: "role-1"
            },
            content: "This is a simulated message from WebSocket",
            timestamp: new Date(),
            edited: null,
            reactions: [],
            replyTo: null,
            threadId: null,
            attachments: []
          };
          addMessage(currentChannel, mockMessage);
        }
      };

      const interval = setInterval(simulateIncomingMessage, 10000);

      return () => {
        clearInterval(interval);
        console.log("WebSocket disconnected");
      };
    };

    const disconnect = connect();

    return () => {
      disconnect();
      if (reconnectTimeoutRef.current) {
        clearTimeout(reconnectTimeoutRef.current);
      }
    };
  }, [token, currentChannel, addMessage]);

  const sendMessage = (channelId: string, content: string) => {
    // Simulate sending message via WebSocket
    const message = {
      id: Date.now().toString(),
      author: {
        id: "1",
        username: "CurrentUser",
        avatar: "👤",
        email: "user@example.com",
        roleId: "role-1"
      },
      content,
      timestamp: new Date(),
      edited: null,
      reactions: [],
      replyTo: null,
      threadId: null,
      attachments: []
    };
    
    addMessage(channelId, message);
    
    // Simulate server confirmation
    setTimeout(() => {
      console.log("Message confirmed by server:", message.id);
    }, 100);
  };

  return { sendMessage };
}