import { useEffect } from "react";
import { useStore } from "../store/useStore";

export function useAuth() {
  const { setAuth, logout, token, user } = useStore();

  const initializeAuth = async () => {
    const storedToken = localStorage.getItem("slate-storage");
    if (storedToken) {
      try {
        const parsed = JSON.parse(storedToken);
        if (parsed.state?.token && parsed.state?.user) {
          setAuth(parsed.state.token, parsed.state.user);
          
          // Simulate token validation and fetch initial data
          await fetchInitialData(parsed.state.token);
        }
      } catch (error) {
        console.error("Failed to parse stored auth:", error);
        logout();
      }
    }
  };

  const fetchInitialData = async (token: string) => {
    // Simulate fetching initial data
    // In a real app, this would make actual API calls
    console.log("Fetching initial data with token:", token);
  };

  const login = async (email: string, password: string) => {
    // Simulate login API call
    return new Promise<{ token: string; user: any }>((resolve, reject) => {
      setTimeout(() => {
        if (email === "user@example.com" && password === "password") {
          const mockUser = {
            id: "1",
            username: "TestUser",
            avatar: "👤",
            email: "user@example.com"
          };
          const mockToken = "mock-jwt-token-" + Date.now();
          resolve({ token: mockToken, user: mockUser });
        } else {
          reject(new Error("Invalid credentials"));
        }
      }, 1000);
    });
  };

  const signup = async (email: string, password: string, username: string) => {
    // Simulate signup API call
    return new Promise<{ token: string; user: any }>((resolve, reject) => {
      setTimeout(() => {
        const mockUser = {
          id: Date.now().toString(),
          username,
          avatar: "👤",
          email
        };
        const mockToken = "mock-jwt-token-" + Date.now();
        resolve({ token: mockToken, user: mockUser });
      }, 1000);
    });
  };

  return {
    initializeAuth,
    login,
    signup,
    logout,
    isAuthenticated: !!token && !!user
  };
}