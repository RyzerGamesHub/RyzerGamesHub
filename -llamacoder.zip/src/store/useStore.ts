import React, { createContext, useContext, useReducer, useEffect } from "react";

interface User {
  id: string;
  username: string;
  avatar: string;
  email: string;
}

interface Role {
  id: string;
  name: string;
  color: string;
  permissions: string[];
}

interface Member {
  id: string;
  userId: string;
  serverId: string;
  roleId: string;
  joinedAt: Date;
  user: User;
  role: Role;
}

interface Server {
  id: string;
  name: string;
  icon: string;
  ownerId: string;
  members: Member[];
}

interface Channel {
  id: string;
  name: string;
  type: "text" | "voice";
  serverId: string;
  permissions: Record<string, string[]>;
}

interface Message {
  id: string;
  author: User & { roleId: string };
  content: string;
  timestamp: Date;
  edited: Date | null;
  reactions: { emoji: string; count: number; userIds: string[] }[];
  replyTo: string | null;
  threadId: string | null;
  attachments: { name: string; url: string; size: number }[];
}

interface Presence {
  userId: string;
  status: "online" | "idle" | "dnd" | "offline";
  lastSeen: Date;
}

interface StoreState {
  token: string | null;
  user: User | null;
  isLoading: boolean;
  currentServer: string | null;
  currentChannel: string | null;
  servers: Map<string, Server>;
  channels: Map<string, Channel>;
  messages: Map<string, Message[]>;
  members: Map<string, Member[]>;
  presence: Map<string, Presence>;
  unread: Map<string, number>;
  typing: Map<string, Set<string>>;
}

type StoreAction =
  | { type: "SET_AUTH"; payload: { token: string; user: User } }
  | { type: "LOGOUT" }
  | { type: "SET_CURRENT_SERVER"; payload: string | null }
  | { type: "SET_CURRENT_CHANNEL"; payload: string | null }
  | { type: "ADD_MESSAGE"; payload: { channelId: string; message: Message } }
  | { type: "UPDATE_MESSAGE"; payload: { channelId: string; messageId: string; content: string } }
  | { type: "DELETE_MESSAGE"; payload: { channelId: string; messageId: string } }
  | { type: "ADD_REACTION"; payload: { channelId: string; messageId: string; emoji: string; userId: string } }
  | { type: "SET_TYPING"; payload: { channelId: string; userId: string; isTyping: boolean } }
  | { type: "UPDATE_UNREAD"; payload: { channelId: string; count: number } }
  | { type: "UPDATE_PRESENCE"; payload: { userId: string; presence: Presence } }
  | { type: "RESTORE_STATE"; payload: Partial<StoreState> };

const initialState: StoreState = {
  token: null,
  user: null,
  isLoading: false,
  currentServer: null,
  currentChannel: null,
  servers: new Map(),
  channels: new Map(),
  messages: new Map(),
  members: new Map(),
  presence: new Map(),
  unread: new Map(),
  typing: new Map(),
};

function storeReducer(state: StoreState, action: StoreAction): StoreState {
  switch (action.type) {
    case "SET_AUTH":
      return { ...state, token: action.payload.token, user: action.payload.user };
    
    case "LOGOUT":
      return {
        ...initialState,
        servers: state.servers,
        channels: state.channels,
        messages: state.messages,
        members: state.members,
        presence: state.presence,
      };
    
    case "SET_CURRENT_SERVER":
      return { ...state, currentServer: action.payload, currentChannel: null };
    
    case "SET_CURRENT_CHANNEL":
      return { ...state, currentChannel: action.payload };
    
    case "ADD_MESSAGE":
      const messages = state.messages.get(action.payload.channelId) || [];
      return {
        ...state,
        messages: new Map(state.messages).set(action.payload.channelId, [...messages, action.payload.message])
      };
    
    case "UPDATE_MESSAGE":
      const channelMessages = state.messages.get(action.payload.channelId) || [];
      const updated = channelMessages.map(m => 
        m.id === action.payload.messageId 
          ? { ...m, content: action.payload.content, edited: new Date() } 
          : m
      );
      return {
        ...state,
        messages: new Map(state.messages).set(action.payload.channelId, updated)
      };
    
    case "DELETE_MESSAGE":
      const msgs = state.messages.get(action.payload.channelId) || [];
      const filtered = msgs.filter(m => m.id !== action.payload.messageId);
      return {
        ...state,
        messages: new Map(state.messages).set(action.payload.channelId, filtered)
      };
    
    case "ADD_REACTION":
      const channelMsgs = state.messages.get(action.payload.channelId) || [];
      const updatedMsgs = channelMsgs.map(m => {
        if (m.id !== action.payload.messageId) return m;
        
        const existingReaction = m.reactions.find(r => r.emoji === action.payload.emoji);
        if (existingReaction) {
          if (existingReaction.userIds.includes(action.payload.userId)) {
            return {
              ...m,
              reactions: m.reactions.map(r =>
                r.emoji === action.payload.emoji
                  ? { ...r, count: r.count - 1, userIds: r.userIds.filter(id => id !== action.payload.userId) }
                  : r
              )
            };
          } else {
            return {
              ...m,
              reactions: m.reactions.map(r =>
                r.emoji === action.payload.emoji
                  ? { ...r, count: r.count + 1, userIds: [...r.userIds, action.payload.userId] }
                  : r
              )
            };
          }
        } else {
          return {
            ...m,
            reactions: [...m.reactions, { emoji: action.payload.emoji, count: 1, userIds: [action.payload.userId] }]
          };
        }
      });
      return {
        ...state,
        messages: new Map(state.messages).set(action.payload.channelId, updatedMsgs)
      };
    
    case "SET_TYPING":
      const typing = new Map(state.typing);
      const channelTyping = typing.get(action.payload.channelId) || new Set();
      
      if (action.payload.isTyping) {
        channelTyping.add(action.payload.userId);
      } else {
        channelTyping.delete(action.payload.userId);
      }
      
      typing.set(action.payload.channelId, channelTyping);
      return { ...state, typing };
    
    case "UPDATE_UNREAD":
      return {
        ...state,
        unread: new Map(state.unread).set(action.payload.channelId, action.payload.count)
      };
    
    case "UPDATE_PRESENCE":
      return {
        ...state,
        presence: new Map(state.presence).set(action.payload.userId, action.payload.presence)
      };
    
    case "RESTORE_STATE":
      return { ...state, ...action.payload };
    
    default:
      return state;
  }
}

interface StoreContextType {
  state: StoreState;
  dispatch: React.Dispatch<StoreAction>;
}

const StoreContext = createContext<StoreContextType | null>(null);

export function StoreProvider({ children }: { children: React.ReactNode }) {
  const [state, dispatch] = useReducer(storeReducer, initialState);

  useEffect(() => {
    const persistedState = {
      token: state.token,
      user: state.user,
      currentServer: state.currentServer,
      currentChannel: state.currentChannel,
    };
    localStorage.setItem("slate-storage", JSON.stringify({ state: persistedState }));
  }, [state.token, state.user, state.currentServer, state.currentChannel]);

  useEffect(() => {
    const stored = localStorage.getItem("slate-storage");
    if (stored) {
      try {
        const parsed = JSON.parse(stored);
        if (parsed.state) {
          dispatch({ type: "RESTORE_STATE", payload: parsed.state });
        }
      } catch (error) {
        console.error("Failed to restore state:", error);
      }
    }
  }, []);

  const contextValue: StoreContextType = { state, dispatch };

  return React.createElement(
    StoreContext.Provider,
    { value: contextValue },
    children
  );
}

export function useStore() {
  const context = useContext(StoreContext);
  if (!context) {
    throw new Error("useStore must be used within a StoreProvider");
  }
  
  const { state, dispatch } = context;
  
  return {
    ...state,
    setAuth: (token: string, user: User) => dispatch({ type: "SET_AUTH", payload: { token, user } }),
    logout: () => dispatch({ type: "LOGOUT" }),
    setCurrentServer: (serverId: string | null) => dispatch({ type: "SET_CURRENT_SERVER", payload: serverId }),
    setCurrentChannel: (channelId: string | null) => dispatch({ type: "SET_CURRENT_CHANNEL", payload: channelId }),
    addMessage: (channelId: string, message: Message) => dispatch({ type: "ADD_MESSAGE", payload: { channelId, message } }),
    updateMessage: (channelId: string, messageId: string, content: string) => dispatch({ type: "UPDATE_MESSAGE", payload: { channelId, messageId, content } }),
    deleteMessage: (channelId: string, messageId: string) => dispatch({ type: "DELETE_MESSAGE", payload: { channelId, messageId } }),
    addReaction: (channelId: string, messageId: string, emoji: string, userId: string) => dispatch({ type: "ADD_REACTION", payload: { channelId, messageId, emoji, userId } }),
    setTyping: (channelId: string, userId: string, isTyping: boolean) => dispatch({ type: "SET_TYPING", payload: { channelId, userId, isTyping } }),
    updateUnread: (channelId: string, count: number) => dispatch({ type: "UPDATE_UNREAD", payload: { channelId, count } }),
    updatePresence: (userId: string, presence: Presence) => dispatch({ type: "UPDATE_PRESENCE", payload: { userId, presence } }),
  };
}