export function parseMarkdown(text: string): React.ReactNode {
  // Simple markdown parser for basic formatting
  let parsed = text;
  
  // Bold: **text** -> <strong>text</strong>
  parsed = parsed.replace(/\*\*(.*?)\*\*/g, "<strong>$1</strong>");
  
  // Italic: *text* -> <em>text</em>
  parsed = parsed.replace(/\*(.*?)\*/g, "<em>$1</em>");
  
  // Code: `code` -> <code>code</code>
  parsed = parsed.replace(/`(.*?)`/g, "<code class='bg-gray-700 px-1 rounded text-sm'>$1</code>");
  
  // Line breaks
  parsed = parsed.replace(/\n/g, "<br>");
  
  return <span dangerouslySetInnerHTML={{ __html: parsed }} />;
}